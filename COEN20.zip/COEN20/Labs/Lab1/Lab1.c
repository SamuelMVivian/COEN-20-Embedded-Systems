#include <stdint.h>

//Converts 8-bit number to unsigned decimal the formula 2*n+bi recursively
uint32_t Bits2Unsigned(int8_t bits[8]) {
  uint32_t n=0;
  for(uint32_t i=8;i>0;i--){
    n=2*n+bits[i-1];
  }
  return n;
}

//Converts 8-bit number to signed decimal by calling Bits2Unsigned
//and subracting -2*2^(largest bit) if its negative
int32_t	Bits2Signed(int8_t bits[8]) {
  if(bits[7]==1){
    return -128*2+Bits2Unsigned(bits);
  }else{
    return Bits2Unsigned(bits);
  }
}

//Increments the 8-bit number by finding the first zero from right to left changing it to a 1
//Then changes all smaller bits to zero
//If all 8-bits are one (number is at maximum) sets all bits to zero
void Increment(int8_t bits[8]) {
  for(uint32_t i=0; i<8; i++){
    if(bits[i]==0){
      bits[i]=1;
      for(uint32_t j=0;j<i;j++){
        bits[j]=0;
      }
      break;
    }
  }
}

//converts unsigned decimal number to bits making each bit from right to left
//nmod2 and then flooring n
void Unsigned2Bits(uint32_t n, int8_t bits[8]) {
  uint32_t counter = 0;
  for(int i = 0; i<8; i++){
    bits[i]=0;
  }
  while(n>0&&counter<8){
    bits[counter] = n % 2;
    n/=2;
    counter++;
  }
}
